package varios;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import sql.SQL;

public class CrearEmpleados {
	public static void ejecutar(Connection conx) throws SQLException {
		// Crear la base de datos 'empresa'
		ResultSet databases2 = SQL.obtenerRS(conx, "empleados");
		boolean empresa = false;
		while (databases2.next()) {
			if (databases2.getString(1).equals("empresa")) {
				empresa = true;
			}
		}
		if (!empresa) {
			SQL.ejecutarSql(conx, "CREATE DATABASE empresa");
		}
		// Usar la base de datos 'empresa'
		SQL.ejecutarSql(conx, "USE empresa");
		ResultSet tables = SQL.obtenerRS(conx, "show tables");
		boolean departamentos = false;
		boolean empleados = false;
		while (tables.next()) {
			if (tables.getString(1).equals("departamentos")) {
				departamentos = true;
			}
			if (tables.getString(1).equals("empleados")) {
				empleados = true;
			} 
		}
		// Crear la tabla 'departamentos'
		if(!departamentos) {
		SQL.ejecutarSql(
				conx,
				"CREATE TABLE departamentos (" + "departamento_id INT PRIMARY KEY, " + "nombre VARCHAR(50)" + ")");
		departamentos=false;
		}
		// Crear la tabla 'empleados'
		if(!empleados) {
		SQL.ejecutarSql(conx, "CREATE TABLE empleados (" + "dni VARCHAR(9) PRIMARY KEY, " + "nombre VARCHAR(50), "
						+ "apellido VARCHAR(50), " + "salario DOUBLE, " + "telefono VARCHAR(9), "
						+ "departamento_id INT, " + "FOREIGN KEY (departamento_id) REFERENCES departamentos(departamento_id)"
						+ ")");
		empleados=false;
		}
		// Insertar departamentos
		;
		ResultSet rs = SQL.obtenerRS(conx, "Select * from departamentos");
		int i = 1;
		while(rs.next()) {
			i++;
		}
		SQL.ejecutarSql(conx, "INSERT INTO departamentos (departamento_id, nombre) VALUES " + "("+i+++", 'Recursos Humanos'), "
						+ "("+i+++", 'Ventas'), " + "("+i+++", 'Desarrollo'), " + "("+i+++", 'Marketing'), " + "("+i+++", 'Finanzas');");

		// Insertar 10 empleados en la tabla 'empleados' con 'departamento_id'
		SQL.ejecutarSql(conx, "INSERT INTO empleados (dni, nombre, apellido, salario, telefono, departamento_id) VALUES "
						+ "('"+(int)(Math.random()*100000000)+"C', 'Juan', 'Pérez', 25000.50, '600123456', 1), "
						+ "('"+(int)(Math.random()*100000000)+"B', 'Ana', 'García', 27000.00, '611234567', 2), "
						+ "('"+(int)(Math.random()*100000000)+"C', 'Luis', 'Martín', 30000.75, '622345678', 3), "
						+ "('"+(int)(Math.random()*100000000)+"D', 'María', 'López', 32000.20, '633456789', 4), "
						+ "('"+(int)(Math.random()*100000000)+"E', 'Carlos', 'Sánchez', 35000.10, '644567890', 5), "
						+ "('"+(int)(Math.random()*100000000)+"F', 'Marta', 'Ramírez', 29000.00, '655678901', 1), "
						+ "('"+(int)(Math.random()*100000000)+"G', 'Javier', 'Díaz', 31000.85, '666789012', 2), "
						+ "('"+(int)(Math.random()*100000000)+"H', 'Sofía', 'Fernández', 33000.40, '677890123', 3), "
						+ "('"+(int)(Math.random()*100000000)+"I', 'Raúl', 'Gómez', 34000.60, '688901234', 4), "
						+ "('"+(int)(Math.random()*100000000)+"J', 'Laura', 'Morales', 36000.95, '699012345', 5);");

		System.out.println(
				"Base de datos 'empresa' creada con la tabla 'empleados', 'departamentos' y registros insertados.");

	}
}
