package controladores;

import java.util.Comparator;

import entidades.Empleado;

public class comparadorApellido implements Comparator<Empleado> {

    @Override
    public int compare(Empleado o1, Empleado o2) {
        return o1.getApellido().compareTo(o2.getApellido());
    }
}
