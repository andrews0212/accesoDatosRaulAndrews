package controladores;

import java.util.Comparator;

import entidades.Empleado;

public class comparadorSalario implements Comparator<Empleado> {

    @Override
    public int compare(Empleado o1, Empleado o2) {
        return Double.compare(o1.getSalario(), o2.getSalario());
    }
}
