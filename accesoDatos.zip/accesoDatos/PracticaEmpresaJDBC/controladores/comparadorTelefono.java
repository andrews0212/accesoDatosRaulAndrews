package controladores;

import java.util.Comparator;

import entidades.Empleado;

public class comparadorTelefono implements Comparator<Empleado> {

    @Override
    public int compare(Empleado o1, Empleado o2) {
        return o1.getTelefono().compareTo(o2.getTelefono());
    }
}
