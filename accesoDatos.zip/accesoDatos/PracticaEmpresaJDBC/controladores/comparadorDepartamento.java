package controladores;

import java.util.Comparator;

import entidades.Empleado;

public class comparadorDepartamento implements Comparator<Empleado> {

	@Override
	public int compare(Empleado o1, Empleado o2) {
		// TODO Auto-generated method stub
		return Integer.compare(o1.getDepartamento(), o2.getDepartamento()) ;
	}

}
