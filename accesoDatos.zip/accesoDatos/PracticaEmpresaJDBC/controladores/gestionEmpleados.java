package controladores;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import entidades.*;
public class gestionEmpleados {
	private ArrayList<Empleado> listaEmpleados;

    public gestionEmpleados() {
        this.listaEmpleados = new ArrayList<>();
    }
    public gestionEmpleados(ArrayList<Empleado> array) {
        this.listaEmpleados = array;
    }

    public List<Empleado> getListaEmpleados() {
		return listaEmpleados;
	}

	// Método para añadir un empleado
    public void añadirEmpleado(Empleado empleado) {
        this.listaEmpleados.add(empleado);
    }

    // Método para ordenar la lista de empleados
    public void ordenarEmpleados() {
        Collections.sort(listaEmpleados); // Utiliza el compareTo definido en Empleado
    }

    // Método para mostrar todos los empleados
    public void mostrarEmpleados() {
        for (Empleado emp : listaEmpleados) {
            System.out.println(emp.toString());
        }
    }
}
