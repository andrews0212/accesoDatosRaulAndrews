package controladores;

import java.util.Comparator;

import entidades.departamento;

public class comparadorNombreDepartamento implements Comparator<departamento> {
	@Override
	public int compare(departamento o1, departamento o2) {
		return o1.getNombre().compareTo(o2.getNombre());
	}

}
