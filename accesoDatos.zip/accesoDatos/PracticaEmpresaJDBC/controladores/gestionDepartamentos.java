package controladores;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import entidades.*;

public class gestionDepartamentos {
	private ArrayList<departamento> listaDepartamentos;

    // Constructor sin parámetros
    public gestionDepartamentos() {
        this.listaDepartamentos = new ArrayList<>();
    }

    // Constructor que recibe una lista de departamentos
    public gestionDepartamentos(ArrayList<departamento> array) {
        this.listaDepartamentos = array;
    }

    // Obtener la lista de departamentos
    public List<departamento> getListaDepartamentos() {
		return listaDepartamentos;
	}

	// Método para añadir un departamento
    public void añadirDepartamento(departamento departamento) {
        this.listaDepartamentos.add(departamento);
    }

    // Método para ordenar la lista de departamentos
    public void ordenarDepartamentos() {
        Collections.sort(listaDepartamentos); // Utiliza el compareTo definido en Departamento
    }

    // Método para mostrar todos los departamentos
    public void mostrarDepartamentos() {
        for (departamento dept : listaDepartamentos) {
            System.out.println(dept.toString());
        }
    }
}
