package main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

import controladores.*;
import entidades.Empleado;

public class mainLista {
	public static void main(String[] args) {
		try {
			gestionEmpleados gestion = new gestionEmpleados();
			gestion.añadirEmpleado(new Empleado("12345678A", "Juan", "García", 25000, "600123456"));
			gestion.añadirEmpleado(new Empleado("23456789B", "Ana", "Martínez", 30000, "600234567"));
			gestion.añadirEmpleado(new Empleado("34567890C", "Carlos", "López", 28000, "600345678"));
			gestion.añadirEmpleado(new Empleado("45678901D", "María", "Fernández", 27000, "600456789"));
			gestion.añadirEmpleado(new Empleado("56789012E", "Luis", "Pérez", 26000, "600567890"));
			gestion.añadirEmpleado(new Empleado("67890123F", "Laura", "Sánchez", 32000, "600678901"));
			gestion.añadirEmpleado(new Empleado("78901234G", "Pablo", "Rodríguez", 24000, "600789012"));
			gestion.añadirEmpleado(new Empleado("89012345H", "Lucía", "Ramírez", 31000, "600890123"));
			gestion.añadirEmpleado(new Empleado("90123456I", "Pedro", "Torres", 29000, "600901234"));
			gestion.añadirEmpleado(new Empleado("01234567J", "Marta", "Hernández", 33000, "600012345"));
			Scanner entrada = new Scanner(System.in);
			boolean salir = false;
			while (!salir) {
				System.out.println(
						"\n1.Mostrar empleados\n2.Añadir empleado\n3.Eliminar empleado\n4.Modificar empleado\n5.Ordenar empleados\n6.Salir");
				String key = entrada.nextLine();
				switch (key) {
				case "1": {
					gestion.mostrarEmpleados();
					break;
				}
				case "2": {
					// Pedir nombre
					System.out.println("Introduce nombre");
					String nombre = entrada.nextLine();

					// Pedir apellido
					System.out.println("Introduce apellido");
					String apellido = entrada.nextLine();

					// Pedir DNI
					System.out.println("Introduce DNI");
					String dni = entrada.nextLine();

					// Pedir salario
					System.out.println("Introduce salario");
					String salario = entrada.nextLine();

					// Pedir sueldo
					System.out.println("Introduce telefono");
					String telefono = entrada.nextLine();
					Empleado emp = new Empleado(dni, nombre, apellido, Double.parseDouble(salario), telefono);
					gestion.añadirEmpleado(emp);
					System.out.println("Se ha añadido a " + emp.toString());
					break;
				}
				case "3": {
					System.out.println("Introduce DNI");
					String dni = entrada.nextLine();
					boolean encontrado = false;
					int indice = 0;
					for (Empleado emp : gestion.getListaEmpleados()) {
						if (emp.getDni().equals(dni)) {
							indice = gestion.getListaEmpleados().indexOf(emp);
							encontrado = true;
							System.out.println("Se ha eliminado a: " + emp.toString());
						}
					}
					if (encontrado)
						gestion.getListaEmpleados().remove(indice);
					break;
				}
				case "4": {
					System.out.println("Introduce DNI");
					String dni = entrada.nextLine();
					for (Empleado emp : gestion.getListaEmpleados()) {
						if (emp.getDni().equals(dni)) {
							boolean salir2 = false;
							while (!salir2) {
								System.out.println(
										"Escribe que campo quieres cambiar\n1.Nombre 2.Apellido 3.DNI 4.Salario 5.Teléfono 6.Ninguno");
								int key2 = entrada.nextInt();
								entrada.nextLine();

								switch (key2) {
								case 1: {
									System.out.println("Introduce nuevo valor");
									emp.setNombre(entrada.nextLine());
								}
								case 2: {
									System.out.println("Introduce nuevo valor para el apellido");
									emp.setApellido(entrada.nextLine());
									break;
								}
								case 3: {
									System.out.println("Introduce nuevo valor para el DNI");
									emp.setDni(entrada.nextLine());
									break;
								}
								case 4: {
									System.out.println("Introduce nuevo valor para el salario");
									emp.setSalario(entrada.nextDouble());
									entrada.nextLine(); // Consumir el salto de línea después de nextDouble()
									break;
								}
								case 5: {
									System.out.println("Introduce nuevo valor para el teléfono");
									emp.setTelefono(entrada.nextLine());
									break;
								}
								case 6: {
									salir2 = true;
									break;
								}
								default:
									System.out.println("Entrada no valida");
								}
							}
						}
					}
					break;
				}
				case "5": {
					System.out.println(
							"Selecciona un criterio para ordenar:\n1.Nombre 2.Apellido 3.DNI 4.Salario 5.Teléfono");
					int key3 = entrada.nextInt();
					entrada.nextLine();

					switch (key3) {
					case 1: {
						Collections.sort(gestion.getListaEmpleados(), new comparadorNombre());
						System.out.println("Orden: Nombre");
						gestion.mostrarEmpleados();
						break;
					}
					case 2: {
						System.out.println("Orden: Apellido");
						Collections.sort(gestion.getListaEmpleados(), new comparadorApellido());
						gestion.mostrarEmpleados();
						break;
					}
					case 3: {
						System.out.println("Orden: DNI");
						Collections.sort(gestion.getListaEmpleados());
						gestion.mostrarEmpleados();
						break;
					}
					case 4: {
						System.out.println("Orden: Salario");
						Collections.sort(gestion.getListaEmpleados(), new comparadorSalario());
						gestion.mostrarEmpleados();
						break;
					}
					case 5: {
						System.out.println("Orden: Telefono");
						Collections.sort(gestion.getListaEmpleados(), new comparadorTelefono());
						gestion.mostrarEmpleados();
						break;
					}
					default: {
						System.out.println("Opción no válida. Por favor, selecciona un número del 1 al 5.");
						break;
					}
					}
					break;
				}
				case "6": {
					salir = true;
					break;
				}
				default:
					System.out.println("Entrada no válida");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error al gestionar empleados: " + e.getMessage());
		}
	}
}
