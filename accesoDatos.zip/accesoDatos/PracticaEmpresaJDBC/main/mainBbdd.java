package main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import controladores.comparadorApellido;
import controladores.comparadorDepartamento;
import controladores.comparadorNombre;
import controladores.comparadorNombreDepartamento;
import controladores.comparadorSalario;
import controladores.comparadorTelefono;
import controladores.gestionDepartamentos;
import controladores.gestionEmpleados;
import entidades.departamento;
import entidades.Empleado;
import sql.SQL;
import sql.conexionSingleton;
import varios.CrearEmpleados;

public class mainBbdd {

	public static void main(String[] args) throws SQLException, IOException {
		// INICIAR SERVICIOS

		boolean salirEmpresa = false;
		boolean salirDepartamentos = true;
		boolean salirEmpleados = true;
		Scanner entrada = new Scanner(System.in);

		boolean iniciado = false;
		while (!iniciado) {
			iniciado = iniciarServicio(entrada);

		}

		// INSTANCIAMOS LA CONEXION UNA VEZ SE HA INICIADO EL SERVICIO
		Connection conx = conexionSingleton.getMysql();
		// CONSULTA SI EXISTE LA BBDD EMPRESA
		ResultSet databases2 = SQL.obtenerRS(conx, "show databases");
		boolean empresa = false;
		int i = 1;
		int indiceEmpresa = 1;
		while (databases2.next()) {
			if (databases2.getString(1).equals("empresa")) {
				empresa = true;
				if (empresa) {
					indiceEmpresa = i;
				}
				i++;
			}
		}
		databases2.close();
		// CREA LA BASE DE DATOS EMPRESA SI NO EXISTE
		if (!empresa) {
			System.out.println("No se ha detectado la bbdd empresa ¿Quieres crearla? Y/N");
			if (entrada.nextLine().equalsIgnoreCase("Y")) {
				CrearEmpleados.ejecutar(conx);
				indiceEmpresa = 1;
			}
		}
		// MUESTRA LAS BASES DE DATOS PARA ELEGIR
		ResultSet databases = SQL.obtenerRS(conx, "show databases");
		int i1 = 1;
		System.out.println("Elige una base de datos:");
		while (databases.next()) {
			System.out.print(i1++ + "." + databases.getString(1) + " ");
		}
		databases.close();
		while (!entrada.nextLine().equals(indiceEmpresa + "")) {
			System.out.println("Tristemente debes seleccionar empresa");
		}
		SQL.ejecutarSql(conx, "use empresa");
		while (!salirEmpresa) {
			System.out.println(
					"\nESTAS USANDO LA BBDD: EMPRESA\n1.Gestionar tablas\n2.Eliminar tabla\n3.Iniciar Servicio\n4.Crear empresa\n5.Eliminar Empresa\n6.Salir");
			String key = entrada.nextLine();
			switch (key) {
			case "1": {
				// MUESTRA TABLAS PARA ELEGIR
				ResultSet tables = SQL.obtenerRS(conx, "show tables");
				System.out.println("Elige una tabla:");
				int i2 = 1;
				int IndDep = 0;
				int IndEmp = 0;
				while (tables.next()) {
					System.out.print(i2 + "." + tables.getString(1) + " ");
					// RECOGER INDICES DE TABLAS
					if (tables.getString(1).equals("empleados")) {
						IndEmp = i2;
					}
					if (tables.getString(1).equals("departamentos")) {
						IndDep = i2;
					}
					i2++;
				}
				tables.close();
				// SE SELECIONA SIGUIENTE MENU
				boolean eleccion = false;
				while (!eleccion) {
					String indice = entrada.nextLine();
					if (indice.equals(IndEmp + "")) {
						salirEmpleados = false;
						eleccion = true;
					} else if (indice.equals(IndDep + "")) {
						salirDepartamentos = false;
						eleccion = true;
					} else {
						System.out.println("Opción no valida");
					}
				}
				// TABLA EMPLEADOS
				while (!salirEmpleados) {
					gestionEmpleados gestion = new gestionEmpleados(obtenerEmpleados(conx));
					System.out.println(
							"\nESTAS USANDO LA BBDD: EMPRESA, TABLA: EMPLEADOS\n1.Mostrar empleados\n2.Añadir empleado\n3.Eliminar empleado\n4.Modificar empleado\n5.Ordenar empleados\n6.Salir");
					String keyEmpleado = entrada.nextLine();
					switch (keyEmpleado) {
					// MOSTRAR EMPLEADOS
					case "1": {
						gestion.mostrarEmpleados();
						// CON EL SIGUIENTE CODIGO SE VERIFICA LA SINCRONÍA ENTRE EL ARRAY Y LA BD
//					System.out.println("\n");
//					gestion = new gestionEmpleados(obtenerEmpleados(conx));
//					gestion.mostrarEmpleados();
						break;
					}
					// AÑADIR EMPLEADOS
					case "2": {
						// Pedir nombre
						System.out.println("Introduce nombre");
						String nombre = entrada.nextLine();

						// Pedir apellido
						System.out.println("Introduce apellido");
						String apellido = entrada.nextLine();

						// Pedir DNI
						System.out.println("Introduce DNI");
						String dni = entrada.nextLine();

						// Pedir salario
						System.out.println("Introduce salario");
						Double salario = Double.parseDouble(entrada.nextLine());

						// Pedir telefono
						System.out.println("Introduce telefono");
						String telefono = entrada.nextLine();
						// Pedir departamento
						System.out.println("Introduce departamento");
						int departamento = Integer.parseInt(entrada.nextLine());
						Empleado emp = new Empleado(dni, nombre, apellido, salario, telefono, departamento);
						SQL.ejecutarSql(conx, String.format(
								"INSERT INTO EMPLEADOS (dni, nombre, apellido, salario, telefono, departamento) VALUES (?, ?, ?, ?, ?, ?);",
								emp.getDni(), emp.getNombre(), emp.getApellido(), emp.getSalario(), emp.getTelefono(),
								emp.getDepartamento()));
						// Ya no hace falta por la validación de empleado y la entrada de datos
						// emp.getX: un empleado no puede llamarse drop database
//							String sql = "INSERT INTO empleados (dni, nombre, apellido, salario, telefono, departamento) VALUES (?, ?, ?, ?, ?, ?)";
//							try (PreparedStatement pstmt = conx.prepareStatement(sql)) {
//								pstmt.setString(1, emp.getDni());
//								pstmt.setString(2, emp.getNombre());
//								pstmt.setString(3, emp.getApellido());
//								pstmt.setDouble(4, emp.getSalario());
//								pstmt.setString(5, emp.getTelefono());
//								pstmt.setInt(6, emp.getDepartamento());
//								pstmt.executeUpdate();
//								conx.commit();
//								System.out.println("Empleado agregado con éxito.");
//								gestion.añadirEmpleado(emp);
//							} catch (SQLException e) {
//								e.printStackTrace();
//							}
						break;
					}
					// ELIMINAR EMPLEADO
					case "3": {
						System.out.println("Introduce DNI");
						String dni = entrada.nextLine();
						boolean encontrado = false;
						int indice = 0;
						for (Empleado emp : gestion.getListaEmpleados()) {
							if (emp.getDni().equals(dni)) {
								indice = gestion.getListaEmpleados().indexOf(emp);
								encontrado = true;
								System.out.println("Se ha eliminado a: " + emp.toString());
							}
						}
						if (encontrado) {
							SQL.ejecutarSql(conx, "delete from empleados where DNI='"
									+ gestion.getListaEmpleados().get(indice).getDni() + "';");
							gestion.getListaEmpleados().remove(indice);
						}

						break;
					}
					// MODIFICAR EMPLEADO (Las sentencias sql deberían ser prepared)
					case "4": {
						System.out.println("Introduce DNI");
						String dni = entrada.nextLine();
						for (Empleado emp : gestion.getListaEmpleados()) {
							if (emp.getDni().equals(dni)) {
								boolean salir2 = false;
								while (!salir2) {
									System.out.println(
											"Escribe que campo quieres cambiar\n1.Nombre 2.Apellido 3.DNI 4.Salario 5.Teléfono 6.Departamento 7.Salir");
									int key2 = entrada.nextInt();
									entrada.nextLine();

									switch (key2) {
									case 1: {
										System.out.println("Introduce nuevo valor");
										emp.setNombre(entrada.nextLine());
										SQL.ejecutarSql(conx, "update empleados set nombre ='" + emp.getNombre()
												+ "' where dni='" + dni + "'");
										break;

									}
									case 2: {
										System.out.println("Introduce nuevo valor para el apellido");
										emp.setApellido(entrada.nextLine());
										SQL.ejecutarSql(conx, "UPDATE empleados SET apellido = '" + emp.getApellido()
												+ "' WHERE dni = '" + dni + "'");
										break;
									}
									case 3: {
										System.out.println("Introduce nuevo valor para el DNI");
										emp.setDni(entrada.nextLine());
										SQL.ejecutarSql(conx, "UPDATE empleados SET dni = '" + emp.getDni()
												+ "' WHERE dni = '" + dni + "'");
										break;
									}
									case 4: {
										System.out.println("Introduce nuevo valor para el salario");
										emp.setSalario(entrada.nextDouble());
										entrada.nextLine(); // Consumir el salto de línea después de nextDouble()
										SQL.ejecutarSql(conx, "UPDATE empleados SET salario = " + emp.getSalario()
												+ " WHERE dni = '" + dni + "'");
										break;
									}
									case 5: {
										System.out.println("Introduce nuevo valor para el teléfono");
										emp.setTelefono(entrada.nextLine());
										SQL.ejecutarSql(conx, "UPDATE empleados SET telefono = '" + emp.getTelefono()
												+ "' WHERE dni = '" + dni + "'");
										break;
									}
									case 6: {
										System.out.println("Introduce nuevo valor para el departamento");
										emp.setDepartamento(Integer.parseInt(entrada.nextLine()));
										SQL.ejecutarSql(conx, "UPDATE empleados SET telefono = '" + emp.getTelefono()
												+ "' WHERE dni = '" + dni + "'");
										break;
									}
									case 7: {
										salir2 = true;
										break;
									}
									default:
										System.out.println("Entrada no valida");
									}
									System.out.println("Campos actualizados");
									conx.commit();
								}
							}
						}
						break;
					}
					// ORDENAR EMPLEADOS
					// utilizamos la funcionalidad de gestion empleados ya que el array actua de
					// forma síncrona con la bbdd para ahorrar sentencias sql
					case "5": {
						System.out.println(
								"Selecciona un criterio para ordenar:\n1.Nombre 2.Apellido 3.DNI 4.Salario 5.Teléfono 6.Departamento");
						int key3 = entrada.nextInt();
						entrada.nextLine();

						switch (key3) {
						case 1: {
							Collections.sort(gestion.getListaEmpleados(), new comparadorNombre());
							System.out.println("Orden: Nombre");
							gestion.mostrarEmpleados();
							break;
						}
						case 2: {
							System.out.println("Orden: Apellido");
							Collections.sort(gestion.getListaEmpleados(), new comparadorApellido());
							gestion.mostrarEmpleados();
							break;
						}
						case 3: {
							System.out.println("Orden: DNI");
							Collections.sort(gestion.getListaEmpleados());
							gestion.mostrarEmpleados();
							break;
						}
						case 4: {
							System.out.println("Orden: Salario");
							Collections.sort(gestion.getListaEmpleados(), new comparadorSalario());
							gestion.mostrarEmpleados();
							break;
						}
						case 5: {
							System.out.println("Orden: Telefono");
							Collections.sort(gestion.getListaEmpleados(), new comparadorTelefono());
							gestion.mostrarEmpleados();
							break;
						}
						case 6: {
							System.out.println("Orden: Departamento");
							Collections.sort(gestion.getListaEmpleados(), new comparadorDepartamento());
							gestion.mostrarEmpleados();
							break;
						}
						default: {
							System.out.println("Opción no válida. Por favor, selecciona un número del 1 al 6.");
							break;
						}
						}
						break;
					}
					case "6": {
						salirEmpleados = true;
						break;
					}
					default:
						System.out.println("Entrada no válida");
					}
				}
				// MENU DEPARTAMENTOS
				while (!salirDepartamentos) {
					gestionDepartamentos gestion = new gestionDepartamentos(obtenerDepartamentos(conx));
					System.out.println(
							"\nESTAS USANDO LA BBDD: EMPRESA, TABLA: DEPARTAMENTOS\n1.Mostrar departamentos\n2.Añadir departamento\n3.Eliminar departamento\n4.Modificar departamento\n5.Ordenar departamentos\n6.Salir");
					String keyDepartamentos = entrada.nextLine();
					switch (keyDepartamentos) {
					// MOSTRAR DEPARTAMENTOS
					case "1": {
						gestion.mostrarDepartamentos();
						break;
					}
					// AÑADIR DEPARTAMENTO
					case "2": {
						// Pedir id departamento
						System.out.println("Introduce ID del departamento");
						int idDepartamento = Integer.parseInt(entrada.nextLine());

						// Pedir nombre del departamento
						System.out.println("Introduce nombre del departamento");
						String nombreDepartamento = entrada.nextLine();

						departamento dept = new departamento(idDepartamento, nombreDepartamento);
						String sql = "INSERT INTO departamentos (departamento_id, nombre) VALUES (?, ?)";
						try (PreparedStatement pstmt = conx.prepareStatement(sql)) {
							pstmt.setInt(1, idDepartamento);
							pstmt.setString(2, nombreDepartamento);
							pstmt.executeUpdate();
							conx.commit();
							System.out.println("Departamento agregado con éxito.");
							gestion.añadirDepartamento(dept);
						} catch (SQLException e) {
							e.printStackTrace();
						}
						break;
					}
					// ELIMINAR DEPARTAMENTO
					case "3": {
						System.out.println("Introduce ID del departamento");
						int idDepartamento = Integer.parseInt(entrada.nextLine());
						boolean encontrado = false;
						int indice = 0;
						for (departamento dept : gestion.getListaDepartamentos()) {
							if (dept.getId() == idDepartamento) {
								indice = gestion.getListaDepartamentos().indexOf(dept);
								encontrado = true;
								System.out.println("Se ha eliminado el departamento: " + dept.toString());
							}
						}
						if (encontrado) {
							gestion.getListaDepartamentos().remove(indice);
							SQL.ejecutarSql(conx,
									"DELETE FROM departamentos WHERE departamento_id = " + idDepartamento);
							conx.commit();
						}
						break;
					}
					// MODIFICAR DEPARTAMENTO
					case "4": {
						System.out.println("Introduce ID del departamento");
						int idDepartamento = Integer.parseInt(entrada.nextLine());
						for (departamento dept : gestion.getListaDepartamentos()) {
							if (dept.getId() == idDepartamento) {
								boolean salir2 = false;
								while (!salir2) {
									System.out.println("Escribe que campo quieres cambiar\n1.Nombre 2.Salir");
									int key2 = entrada.nextInt();
									entrada.nextLine();

									switch (key2) {
									case 1: {
										System.out.println("Introduce nuevo valor para el nombre");
										dept.setNombre(entrada.nextLine());
										SQL.ejecutarSql(conx, "UPDATE departamentos SET nombre = '" + dept.getNombre()
												+ "' WHERE departamento_id = " + idDepartamento);
										break;
									}
									case 2: {
										salir2 = true;
										break;
									}
									default:
										System.out.println("Entrada no válida");
									}
									System.out.println("Campos actualizados");
									conx.commit();
								}
							}
						}
						break;
					}
					// ORDENAR DEPARTAMENTOS
					case "5": {
						System.out.println("Selecciona un criterio para ordenar:\n1.ID 2.Nombre");
						int key3 = entrada.nextInt();
						entrada.nextLine();

						switch (key3) {
						case 1: {
							Collections.sort(gestion.getListaDepartamentos());
							System.out.println("Orden: ID");
							gestion.mostrarDepartamentos();
							break;
						}
						case 2: {
							System.out.println("Orden: Nombre");
							Collections.sort(gestion.getListaDepartamentos(), new comparadorNombreDepartamento());
							gestion.mostrarDepartamentos();
							break;
						}
						default: {
							System.out.println("Opción no válida. Por favor, selecciona un número del 1 al 2.");
							break;
						}
						}
						break;
					}
					// SALIR
					case "6": {
						salirDepartamentos = true;
						break;
					}
					default:
						System.out.println("Entrada no válida");
					}
				}
				break;
			}
			case "2": {
				System.out.println("Nombra la tabla a eliminar");
				Statement stmt = conx.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
				ResultSet tables = stmt.executeQuery("show tables");
				while (tables.next()) {
					System.out.println(tables.getString(1));
				}
				String tablaEliminar = entrada.nextLine();
				tables.beforeFirst();
				while (tables.next()) {
					if (tablaEliminar.equalsIgnoreCase(tables.getString(1))) {
						SQL.ejecutarSql(conx, "drop table " + tables.getString(1));
					}
				}
				tables.close();
				break;
			}
			case "3": {
				iniciarServicio(entrada);
				break;
			}
			case "4": {
				CrearEmpleados.ejecutar(conx);
				break;
			}
			case "5": {
				SQL.ejecutarSql(conx, "drop database empresa");
				System.out.println("Base de datos eliminada");
				salirEmpresa = true;
				break;
			}
			case "6": {
				salirEmpresa = true;
				break;
			}
			default: {
				System.out.println("Entrada no válida");
			}
			}
		}
		SQL.cerrarRecursos();
		System.out.println("¿Confirmar cambios? Y/N");
		if (entrada.nextLine().equalsIgnoreCase("Y")) {
			conx.commit();
		}
		conx.close();
		entrada.close();
		System.out.println("Hasta pronto");
	}

	// METODO PARA INICIAR SERVICIO
	private static boolean iniciarServicio(Scanner entrada) throws IOException {
		System.out.println("¿Quieres iniciar algún servicio? Y/X");
		if (entrada.nextLine().equalsIgnoreCase("Y")) {
			System.out.println("Indica el servicio a iniciar");
			String servicio = entrada.nextLine();
			File clase = new File("bin");
			String ruta = clase.getAbsolutePath();
			ProcessBuilder pb = new ProcessBuilder("java", "-cp", ruta, ".iniciarServicio");
			Process proceso = pb.start();
			BufferedReader reader = new BufferedReader(new InputStreamReader(proceso.getInputStream()));
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(proceso.getOutputStream()));
			String line = reader.readLine();
			while (line != null) {
				System.out.println(line);
				if (line.contains("contraseña")) {
					String contraseña = entrada.nextLine();
					writer.write(contraseña);
					writer.flush();
				}
				if (line.contains("Iniciando")) {
					writer.write(servicio + "\n");
					writer.flush();
				}
				line = reader.readLine();
			}
		}
		return true;
	}

	// METODO PARA OBTENER UNA LISTA DE EMPLEADOS DE LA TABLA EMPLEADOS
	public static ArrayList<Empleado> obtenerEmpleados(Connection conexion) {
		ArrayList<Empleado> lista = new ArrayList<Empleado>();
		try (Statement stm = conexion.createStatement();
				ResultSet resultado = stm.executeQuery("Select * from empleados")) {
			while (resultado.next()) {
				Empleado emp = new Empleado(resultado.getString(1), resultado.getString(2), resultado.getString(3),
						resultado.getDouble(4), resultado.getString(5), resultado.getInt(6));
				lista.add(emp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lista;
	}

	// METODO PARA OBTENER UNA LISTA DE DEPARTAMENTOS DE LA TABLA DEPARTAMENTOS
	public static ArrayList<departamento> obtenerDepartamentos(Connection conexion) {
		ArrayList<departamento> lista = new ArrayList<departamento>();
		try (Statement stm = conexion.createStatement();
				ResultSet resultado = stm.executeQuery("SELECT * FROM departamentos")) {
			while (resultado.next()) {
				departamento dept = new departamento(resultado.getInt(1), resultado.getString(2));
				lista.add(dept);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lista;
	}
}