package entidades;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Empleado implements Comparable<Empleado> {
    
    private String dni;
    private String nombre;
    private String apellido;
    private double salario;
    private String telefono;
    private int departamento;
    private ArrayList<String> datos = new ArrayList<String>(); 
    
    
    public Empleado(String dni, String nombre, String apellido, double salario, String telefono, int departamento){
    	
        try {
        	String validadorDni = "^[0-9]{8}[A-Z]$";
        	Pattern myPatternDni = Pattern.compile(validadorDni);
            Matcher myMatcherDni = myPatternDni.matcher(dni);
            if (myMatcherDni.matches())
            	this.dni = dni;
            else
            	throw new Exception("Error de DNI");
            
            String validadorNombre = "^[A-Z][a-záéíóú]{1,15}( [A-Z]?[a-záéíóú]{1,15})?$";
        	Pattern myPatternNombre = Pattern.compile(validadorNombre);
            Matcher myMatcherNombre = myPatternNombre.matcher(nombre);
            if (myMatcherNombre.matches())
            	this.nombre = nombre;
            else
            	throw new Exception("Error de Nombre");
			if (myMatcherNombre.matches())
            	this.apellido = apellido;
            else
            	throw new Exception("Error de Apellido");

			this.salario = salario;
			
			String validadorTelefono = "^[0-9]{9}$";
        	Pattern myPatternTelefono = Pattern.compile(validadorTelefono);
            Matcher myMatcherTelefono = myPatternTelefono.matcher(telefono);
            if (myMatcherTelefono.matches())
            	this.telefono = telefono;
            else
            	throw new Exception("Error de Telefono");
            try {
            	this.departamento=departamento;
            }catch (Exception e) {
            	System.out.println("Error de departamento");
			}
            datos.add(this.dni);
            datos.add(this.nombre);
            datos.add(this.apellido);
            datos.add(this.salario+"");
            datos.add(this.telefono);
            datos.add(this.departamento+"");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Error en la validación de datos del empleado: " + e.getMessage());
		}
        
    }
 public Empleado(String dni, String nombre, String apellido, double salario, String telefono){
    	
        try {
        	String validadorDni = "^[0-9]{8}[A-Z]$";
        	Pattern myPatternDni = Pattern.compile(validadorDni);
            Matcher myMatcherDni = myPatternDni.matcher(dni);
            if (myMatcherDni.matches())
            	this.dni = dni;
            else
            	throw new Exception("Error de DNI");
            
            String validadorNombre = "^[A-Z][a-záéíóú]{1,15}$";
        	Pattern myPatternNombre = Pattern.compile(validadorNombre);
            Matcher myMatcherNombre = myPatternNombre.matcher(nombre);
            if (myMatcherNombre.matches())
            	this.nombre = nombre;
            else
            	throw new Exception("Error de Nombre");
			
			Matcher myMatcherApellido = myPatternNombre.matcher(apellido);
			if (myMatcherApellido.matches())
            	this.apellido = apellido;
            else
            	throw new Exception("Error de Apellido");

			this.salario = salario;
			
			String validadorTelefono = "^[0-9]{9}$";
        	Pattern myPatternTelefono = Pattern.compile(validadorTelefono);
            Matcher myMatcherTelefono = myPatternTelefono.matcher(telefono);
            if (myMatcherTelefono.matches())
            	this.telefono = telefono;
            else
            	throw new Exception("Error de Telefono");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Error en la validación de datos del empleado: " + e.getMessage());
		}
        
    }

    public int getDepartamento() {
		return departamento;
	}

	public void setDepartamento(int departamento) {
		this.departamento = departamento;
	}

	// Getters y Setters
    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public ArrayList<String> getDatos() {
		return datos;
	}
	// Método toString para imprimir información del empleado
    @Override
    public String toString() {
        return "Empleado{" +
                "dni='" + dni + '\'' +
                ", nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", salario=" + salario +
                ", telefono='" + telefono + '\'' +
                '}';
    }
    @Override
	public int compareTo(Empleado emp) {
		return this.dni.compareTo(emp.getDni());
	}

}
