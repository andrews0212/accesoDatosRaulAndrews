package entidades;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class departamento implements Comparable<departamento> {
	private int id;
	private String nombre;

	public departamento(int id, String nombre) {
		try {
			if (id > 0) {
				this.id = id;
			} else {
				throw new Exception("Error de ID de Departamento");
			}
			String validadorNombre = "^[A-Z][a-záéíóú]{1,15}( [A-Z]?[a-záéíóú]{1,15})?$";
        	Pattern myPatternNombre = Pattern.compile(validadorNombre);
            Matcher myMatcherNombre = myPatternNombre.matcher(nombre);
            if (myMatcherNombre.matches())
            	this.nombre = nombre;
            else
            	throw new Exception("Error de Nombre");

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error en la validación de datos del departamento: " + e.getMessage());
		}
	}

	// Getters y Setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	// Método toString para imprimir información del departamento
	@Override
	public String toString() {
		return "Departamento{" + "id=" + id + ", nombre='" + nombre + '\'' + '}';
	}

	@Override
	public int compareTo(departamento o) {
		return Integer.compare(this.id, o.getId());
	}
}
