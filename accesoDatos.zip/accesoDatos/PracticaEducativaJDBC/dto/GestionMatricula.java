package dto;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import dao.Matricula;
import sql.SQL;
import sql.metaDatos;

public class GestionMatricula implements DTO {
	private static String nombreId = "id"; // igual se puede obtener de los metadatos
	private metaDatos metaDatos;
	private ArrayList<Object> registroObjetos;

	// SINCRONIZAR MEMORIA CON BASE DE DATOS
	public GestionMatricula(Connection conexion) {
		metaDatos = new metaDatos(conexion, "matricula");
		registroObjetos = new ArrayList<>();
		// REGISTROS SIN TIPO
		ArrayList<String> registros = SQL.obtenerTabla(conexion, metaDatos);
		for (String registro : registros) {
			registro.replace("(", "");
			registro.replace(")", "");
			ArrayList<String> datos = new ArrayList<String>(Arrays.asList(registro.split(",")));
			// CONSTRUCTOR A PARTIR DE UNA CADENA DE DATOS Y AÑADIR A MEMORIA
			if (datos.isEmpty()) {
				System.out.println("La tabla está vacia");
			} else {
				registroObjetos.add(Matricula.objetoArray(datos));
			}
		}
	}

	// METODO PARA SINCRONIZAR
	@Override
	public void actualizarMemoria(Connection conexion) {
		this.registroObjetos = new GestionMatricula(conexion).getRegistroObjetos();
	}

	// IMPLEMENTACION CRUD
	// CREATE
	@Override
	public boolean insertar(Connection conexion, ArrayList<String> datos) {
		// instanciamos objeto a partir del array para validar
		Matricula objeto = Matricula.objetoArray(datos);
		// obtenemos datos validados
		if (SQL.insertarConId(conexion, metaDatos, objeto.getDatos())) {
			registroObjetos.add(objeto);
			return true;
		}
		return false;
	}

	// READ (DEFAULT EN DTO .obtenerTabla)

	// UPLOAD ESTE NO VA A FUNCIONAR PORQUE LA TABLA NECESITA DOS IDS PARA RECONOCER
	// EL REGISTRO
	@Override
	public boolean actualizar(Connection conexion, /*no se usa*/int id, ArrayList<String> datos) {
		Matricula objeto = Matricula.objetoArray(datos);
		Scanner entrada = new Scanner(System.in);
		System.out.println("Introduce valor:");
		String primerValor = entrada.nextLine();
			System.out.println("Introduce segundo valor");
			String segundoValor = entrada.nextLine();
			if ((primerValor + segundoValor).contains(";")) {
				System.out.println("INYECCIOOOON");
			} else {
				return SQL.actualizarIntermedia(conexion, metaDatos, "idAlumno", "idAsignatura", primerValor, segundoValor,datos);
			}
			return false;
	}
	// DELETE(MODIFICADO POR TABLA INTERMEDIA) ESTE TAMPOCO, HAY QUE MODIFICAR LA
	// CLASE DTO PARA QUE PERMITA INTRODUCIR DOS IDS CON SOBRECARGA Y AÑADIR LOS
	// METODOS SQL CORRESPONDIENTES A ESTOS CASOS
	// NO INVALIDA POSIBLE INYECCION!!!!!!!!!!!

	@Override
	public boolean eliminar(Connection conexion, int id) {
		System.out.println("Elige campo: idAlumno, idAsignatura, ambos");
		//si lo cierro antes del return peta
		Scanner entrada = new Scanner(System.in);
		String respuesta = entrada.nextLine();
		System.out.println("Introduce valor:");
		String primerValor = entrada.nextLine();
		if (respuesta.equalsIgnoreCase("ambos")) {
			System.out.println("Introduce segundo valor");
			String segundoValor = entrada.nextLine();
			if ((primerValor + segundoValor).contains(";")) {
				System.out.println("INYECCIOOOON");
			} else {
				return SQL.eliminar(conexion, metaDatos, "idAlumno", "idAsignatura", primerValor, segundoValor);
			}
			return false;
		} else {
			if ((respuesta + primerValor).contains(";")) {
				System.out.println("INYECCIOOOON");
			} else {
				return SQL.eliminar(conexion, metaDatos, respuesta, primerValor);
			}
			return false;
		}

	}

	// ORDENAR POR SQL Y FILTRAR SON DEFAULT EN DTO(.obtenerTabla) CON LOS
	// ARGUMENTOS CORRESPONDIENTES
	@Override
	public metaDatos getMetaDatos() {
		return metaDatos;
	}

	@Override
	public ArrayList<Object> getRegistroObjetos() {
		// Hay que castear al objeto en cuestión
		return registroObjetos;
	}

	@Override
	public String getNombreId() {
		// TODO Auto-generated method stub
		return nombreId;
	}

}
