package test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import dao.Jugador;
import dto.GestionAlumno;
import entidades.Empleado;
import sql.SQL;
import sql.metaDatos;
import sql.conexionSingleton;
import varios.CrearEmpleados;

public class test {

	public static void main(String[] args) throws SQLException {
		Connection conx = conexionSingleton.getMysql();
		SQL.ejecutarSql(conx, "USE gestion_equipos");
		GestionAlumno gJ = new GestionAlumno(conx);
		gJ.actualizar(conx, 6, new Jugador("Poliko Polika", (float)1.90, (float)75, 5).getDatos());
		conx.commit();
//		gJ.eliminar(conx, 1);
//		gJ.actualizar(conx, 2, new Jugador("Pepe Palitos",(float)1.80,(float)90,4));
//		conx.commit();
//		gJ.actualizarMemoria(conx);
		
		System.out.println(gJ.obtenerTabla(conx, gJ.getMetaDatos()));
	}

}
