package sql;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
//SE EXPLICA SOLA
public class metaDatos {
	private String nombre;
	private String nombreId;
	private ArrayList<String> tipos;
	private ArrayList<String> campos;

	public metaDatos(Connection conexion, String nombre) {
		try {
			this.nombre = nombre;
			// Obtener los metadatos de la base de datos
			DatabaseMetaData metaData = conexion.getMetaData();
			// Obtener los metadatos de las columnas de la tabla
			ResultSet metaDatos = metaData.getColumns(null, null, this.nombre, null);
			ArrayList<String> camposTabla = new ArrayList<>();
			ArrayList<String> tiposTabla = new ArrayList<>();
			while (metaDatos.next()) {
				//DATOS JUGOSOS
				camposTabla.add(metaDatos.getString("COLUMN_NAME"));
				tiposTabla.add(metaDatos.getString("TYPE_NAME"));
			}
			tipos=tiposTabla;
			nombreId=tiposTabla.get(0);
			campos=camposTabla;
		} catch (SQLException e) {
			System.out.println("Error al obtener los datos de la tabla");
			e.printStackTrace();
		}
	}

	public String getNombre() {
		return nombre;
	}


	public ArrayList<String> getTipos() {
		return tipos;
	}

	
	public ArrayList<String> getCampos() {
		return campos;
	}
	
}
