package sql;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import dto.DTO;
import dto.GestionEquipo;
import dto.GestionJugador;
import dto.GestionMatricula;
import dto.GestionAlumno;
import dto.GestionAsignatura;
import varios.CrearEmpleados;
import varios.CrearGestionEducativa;

public class MenuBBDD {

	// METODO PARA INICIAR SERVICIO
	public static boolean iniciarServicio(Scanner entrada) throws IOException {
		System.out.println("¿Quieres iniciar algún servicio? Y/X");
		if (entrada.nextLine().equalsIgnoreCase("Y")) {
			File clase = new File("bin");
			String ruta = clase.getAbsolutePath();
			ProcessBuilder pb = new ProcessBuilder("java", "-cp", ruta, "sql.iniciarServicio");
			Process proceso = pb.start();
			BufferedReader reader = new BufferedReader(new InputStreamReader(proceso.getInputStream()));
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(proceso.getOutputStream()));
			String line = reader.readLine();
			while (line != null) {
				System.out.println(line);
				if (line.contains("contraseña")) {
					String contraseña = entrada.nextLine();
					writer.write(contraseña);
					writer.flush();
				}
				line = reader.readLine();
			}
		}
		return true;
	}

	// EJECUTAR
	public static boolean ejecutar(Scanner entrada) throws SQLException, IOException {

		// INSTANCIAMOS LA CONEXION UNA VEZ SE HA INICIADO EL SERVICIO
		Connection conx = null;
		try {
			conx = conexionSingleton.getMysql();
		} catch (SQLException e) {
			System.out.println("Error de conexión al servicio");
			e.printStackTrace();
		}
		// CONSULTA BASES DE DATOS
		ResultSet databases2 = SQL.obtenerBBDD(conx);
		boolean empleados = false;
		boolean equipos = false;
		boolean educativa = false;
		int i = 1;
		Integer indiceEmpleados = -1;
		Integer indiceEquipos = -2;
		Integer indiceEducativa = -3;
		String nombreEmpleados = null;
		String nombreEquipos = null;
		String nombreEducativa = null;

		while (databases2.next()) {
			String dbName;
			dbName = databases2.getString(1); // Obtener el nombre de la base de datos

			// Comprobar si la base de datos contiene "empleados"
			if (dbName.contains("empleados")) {
				empleados = true;
				indiceEmpleados = i;
				nombreEmpleados = dbName;
			}

			// Comprobar si la base de datos contiene "equipos"
			if (dbName.contains("equipos")) {
				equipos = true;
				indiceEquipos = i;
				nombreEquipos = dbName;
			}

			// Comprobar si la base de datos contiene "educativa"
			if (dbName.contains("educativa")) {
				educativa = true;
				indiceEducativa = i;
				nombreEducativa = dbName;
			}
			i++;
		}
		databases2.close();
		System.out.println("Se han detectado las siguientes bases de datos:");
		if (empleados) {
			System.out.println(indiceEmpleados + ".Gestion empleados");
		}
		if (equipos) {
			System.out.println(indiceEquipos + ".Gestion equipos");
		}
		if (educativa) {
			System.out.println(indiceEducativa + ".Gestion educativa");
		}
		boolean cambios = false;
		// CREA LA BASE DE DATOS SI NO EXISTE
		if (!empleados) {
			System.out.println("No se ha detectado la bbdd empleados ¿Quieres crearla? Y/X");
			if (entrada.nextLine().equalsIgnoreCase("Y")) {
				// FALTA ADAPTAR

				CrearEmpleados.ejecutar(conx);
				cambios = true;
			}
		}
		if (!equipos) {
			System.out.println("No se ha detectado la bbdd jugadores ¿Quieres crearla? Y/X");
			if (entrada.nextLine().equalsIgnoreCase("Y")) {
				// FALTA IMPLEMENTACION SIMILAR
				cambios = true;
				CrearEmpleados.ejecutar(conx);
			}
		}
		if (!educativa) {
			System.out.println("No se ha detectado la bbdd educativa ¿Quieres crearla? Y/X");
			if (entrada.nextLine().equalsIgnoreCase("Y")) {
				CrearGestionEducativa.ejecutar(conx);
				nombreEducativa = "gestion_educativa";
				educativa = true;
				cambios = true;
			}
		}
		if (cambios) {
			if (empleados) {
				System.out.println(indiceEmpleados + ".Gestion empleados");
			}
			if (equipos) {
				System.out.println(indiceEquipos + ".Gestion equipos");
			}
			if (educativa) {
				System.out.println(indiceEducativa + ".Gestion educativa");
			}
		}
		System.out.println("Elige una base de datos (0 para salir):");
		String menu = entrada.nextLine();
		String nombreBBDD = null;
		BBDD bbdd = null;
		// ELIGE BBDD
		if (menu.equals("0")) {
			return false;
		}
		if (menu.equals(indiceEmpleados + "")) {
			nombreBBDD = nombreEmpleados;
			// INSTANCIAMOS BBDD ("USE BBDD")
			bbdd = new BBDD(conx, nombreBBDD);
		}
		if (menu.equals(indiceEquipos + "")) {
			nombreBBDD = nombreEquipos;
			bbdd = new BBDD(conx, nombreBBDD);
		}
		if (menu.equals(indiceEducativa + "")) {
			nombreBBDD = nombreEducativa;
			bbdd = new BBDD(conx, nombreBBDD);
		}
		// FALTAN REFERENCIAS A OTRAS BBDD
		// DESPLIEGA MENU DE BBDD
		// "\nESTAS USANDO LA BBDD: "+nombreBbdd+"\n1.Gestionar tablas\n2.Eliminar
		// tabla\n3.Eliminar "+nombreBbdd+"\n4.Salir");
		System.out.println(bbdd);
		String key = entrada.nextLine();
		switch (key) {
		// GESTIONAR TABLA
		case "1": {
			// EL DTO GENERICO
			dto.DTO dto = null;
			System.out.println("Elige una tabla");
			System.out.println(bbdd.getTablas());
			String tablaElegida = entrada.nextLine();
			// TODAS LAS POSIBLES TABLAS DE TODAS LAS BBDD. EN CASO DE ELEGIR UNA TABLA DE
			// OTRA BBDD NO SE HA EJECUTADO UN USE BBDD ASI QUE ES IRRELEVANTE
			// FALTAN TABLAS
			if (tablaElegida.contains("jugador")) {
				// INSTANCIA CONCRETA DE DTO
				dto = new GestionJugador(conx);
				// MENU PARA GESTIONAR EL DTO
				menuDto(entrada, conx, dto);
			}
			if (tablaElegida.contains("equipo")) {
				dto = new GestionEquipo(conx);
				menuDto(entrada, conx, dto);
			}
			if (tablaElegida.contains("alumno")) {
				dto = new GestionAlumno(conx);
				menuDto(entrada, conx, dto);
			}
			if (tablaElegida.contains("asignatura")) {
				dto = new GestionAsignatura(conx);
				menuDto(entrada, conx, dto);
			}
			// QUEDA SIN ADAPTAR PERO IGUAL SE PUEDE LEER
			if (tablaElegida.contains("matricula")) {
				dto = new GestionMatricula(conx);
				menuDto(entrada, conx, dto);
			}
			break;
		}
		// ELIMINAR TABLA
		case "2": {
			System.out.println("Nombra la tabla a eliminar");
			Statement stmt = conx.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet tables = stmt.executeQuery("show tables");
			while (tables.next()) {
				System.out.println(tables.getString(1));
			}
			String tablaEliminar = entrada.nextLine();
			tables.beforeFirst();
			while (tables.next()) {
				if (tablaEliminar.equalsIgnoreCase(tables.getString(1))) {
					SQL.ejecutarSql(conx, "DROP TABLE " + tables.getString(1));
				}
			}
			stmt.close();
			tables.close();
			break;

		}
		case "3": {
			SQL.ejecutarSql(conx, "DROP DATABASE " + bbdd.getNombreBbdd());
			System.out.println("Base de datos eliminada");
			break;
		}
		case "4": {
			return false;
		}
		// CREAR BBDD
		default:
			break;
		}

		System.out.println("¿Guardar cambios? Y/X");
		String repuesta = entrada.nextLine();
		if (repuesta.equals("Y")) {
			conx.commit();
		}
		return true;

	}

	private static boolean menuDto(Scanner entrada, Connection conx, DTO dto) throws SQLException {
		boolean cambios = false;
		String nombre = dto.getMetaDatos().getNombre();
		System.out.println("1.Leer tabla\n2.Añadir " + nombre + "\n3.Eliminar " + nombre + "\n4.Modificar " + nombre
				+ "\n5.Filtrar " + nombre + "\n6.Ordenar tabla" + "\n7.Salir");
		String key = entrada.nextLine();
		switch (key) {
		case "1": {
			System.out.println(dto.mostrarTabla(dto.obtenerTabla(conx, dto.getMetaDatos())));
			break;
		}
		case "2": {
			ArrayList<String> objetoSVC = new ArrayList<String>();
			// si el primer campo no es "id" --> es una tabla compuesta
			if (!dto.getMetaDatos().getCampos().get(0).equalsIgnoreCase("id")) {
				for (int i = 0; i < dto.getMetaDatos().getCampos().size(); i++) {
					System.out.println(
							"Introduce un nuevo valor para el campo: " + dto.getMetaDatos().getCampos().get(i));
					objetoSVC.add(entrada.nextLine());
				}
				dto.insertar(conx, objetoSVC);
				cambios = true;
			} else {
				// añadimos un elemento id generico por temas de simetría, los metodos estan
				// adaptados a omitir el primer valor de estos arrays porque contienen el id, de
				// no existir este elemento omititriamos un dato importante en lugar del id
				objetoSVC.add("id");
				// empezamos en 1 para saltar el id
				for (int i = 1; i < dto.getMetaDatos().getCampos().size(); i++) {
					System.out.println(
							"Introduce un nuevo valor para el campo: " + dto.getMetaDatos().getCampos().get(i));
					objetoSVC.add(entrada.nextLine());
				}
				dto.insertar(conx, objetoSVC);
				cambios = true;
			}
			break;
		}
		case "3": {
			System.out.println("Introduce " + dto.getNombreId() + " (0 si es una tabla intermedia):");
			String id = entrada.nextLine();
			Integer idNumerico = Integer.parseInt(id);
			dto.eliminar(conx, idNumerico);
			cambios = true;
			break;
		}
		case "4": {
			ArrayList<String> objetoSVC = new ArrayList<String>();
			// si el primer campo no es "id" --> es una tabla compuesta
			if (!dto.getMetaDatos().getCampos().get(0).equalsIgnoreCase("id")) {
				for (int i = 0; i < dto.getMetaDatos().getCampos().size(); i++) {
					System.out.println(
							"Introduce un nuevo valor para el campo: " + dto.getMetaDatos().getCampos().get(i));
					objetoSVC.add(entrada.nextLine());
				}
				dto.actualizar(conx,0, objetoSVC);
				cambios = true;
			} else {
				System.out.println(
						"Introduce " + dto.getNombreId() + " del " + dto.getMetaDatos().getNombre() + " a cambiar");
				String id = entrada.nextLine();
				Integer idNumerico = Integer.parseInt(id);
				//mantener simetría
				objetoSVC.add("id");
				// empezamos en 1 para saltar el id
				for (int i = 1; i < dto.getMetaDatos().getCampos().size(); i++) {
					System.out.println(
							"Introduce un nuevo valor para el campo: " + dto.getMetaDatos().getCampos().get(i));
					objetoSVC.add(entrada.nextLine());
				}
				dto.actualizar(conx, idNumerico, objetoSVC);
				cambios = true;
			}
			break;
		}
		case "5": {
			System.out.println("Introduce campo para filtrar");
			String campo = entrada.nextLine();
			System.out.println("Introduce valor");
			String valor = entrada.nextLine();
			System.out.println(dto.mostrarTabla(dto.obtenerTabla(conx, dto.getMetaDatos(), campo, valor)));
			break;
		}
		case "6": {
			System.out.println("Introduce campo para ordenar");
			String campo = entrada.nextLine();
			System.out.println(dto.mostrarTabla(dto.obtenerTabla(conx, dto.getMetaDatos(), campo)));
			break;
		}
		case "7": {
			return false;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + key);
		}
		if (cambios) {
			System.out.println("¿Guardar cambios? Y/X");
			String repuesta = entrada.nextLine();
			if (repuesta.equalsIgnoreCase("Y")) {
				conx.commit();
				dto.actualizarMemoria(conx);
			}
		}
		sql.MenuBBDD.menuDto(entrada, conx, dto);
		return true;
	}
}
