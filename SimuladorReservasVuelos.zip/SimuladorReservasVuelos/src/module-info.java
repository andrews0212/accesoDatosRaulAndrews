module SimuladorReservasVuelos {
	requires java.desktop;
}