package controlador;

import javax.swing.SwingUtilities;

import vista.Vista;

public class Main {
	public static void main(String[] args) {
		Vista vista = new Vista();
		SwingUtilities.invokeLater(() -> {
			vista.setVisible(true);
		});
	}
}
