package modelo;

public class Modelo {

}
