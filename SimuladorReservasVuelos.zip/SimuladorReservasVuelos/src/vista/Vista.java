package vista;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.*;

public class Vista extends JFrame {
	JPanel arriba;
	JPanel abajo;
	JPanel izquierda;
	JPanel derecha;
	JPanel centro;
	JLabel tNombrePasajero;
	JLabel tEdad;
	JLabel tDestino;
	JLabel tFechaVuelo;
	JTextField nombrePasajero;
	JTextField edad;
	JComboBox<String> destino;
	JTextField fechaVuelo;
	JRadioButton economico;
	JRadioButton primeraClase;
	JRadioButtonMenuItem grupo;
	JTextArea resultado;
	
	public Vista() {
		//DECLARACION Y CONFIGURACION BASICA DE ELEMENTOS
		this.setSize(500, 500);
		this.setLayout(new BorderLayout());
		arriba = new JPanel();
		arriba.setLayout(new BorderLayout());
		abajo = new JPanel();
		izquierda= new JPanel();
		derecha= new JPanel();
		centro = new JPanel();
		tNombrePasajero = new JLabel("Nombre del pasajero:");
		tEdad = new JLabel("Edad:");
		tDestino = new JLabel("Destino:");
		tFechaVuelo = new JLabel("Fecha del vuelo:");
		nombrePasajero= new JTextField();
		edad = new JTextField();
		destino = new JComboBox<String>();
		destino.addItem("Madrid");
		destino.addItem("Barcelona");
		destino.addItem("Paris");
		destino.addItem("Nueva York");
		fechaVuelo= new JTextField();
		economico = new JRadioButton();
		economico.setText("Economico");
		primeraClase = new JRadioButton();
		primeraClase.setText("Primera clase");
		grupo = new JRadioButtonMenuItem();
		grupo.add(economico);
		grupo.add(primeraClase);
		resultado = new JTextArea();
		
		//ESTRUCTURA DE ELEMENTOS
		this.add(arriba, BorderLayout.NORTH);
		this.add(centro, BorderLayout.CENTER);
		this.add(abajo, BorderLayout.SOUTH);
		izquierda.setLayout(new BoxLayout(izquierda, BoxLayout.Y_AXIS));
		derecha.setLayout(new BoxLayout(derecha, BoxLayout.Y_AXIS));
		arriba.add(izquierda, BorderLayout.WEST);
		arriba.add(derecha, BorderLayout.CENTER);
		izquierda.add(tNombrePasajero);
		izquierda.add(tEdad);
		izquierda.add(tDestino);
		izquierda.add(tFechaVuelo);
		derecha.add(nombrePasajero);
		derecha.add(edad);
		derecha.add(destino);
		derecha.add(fechaVuelo);
		centro.add(economico);
		centro.add(primeraClase);
		abajo.add(resultado);
	}
}
