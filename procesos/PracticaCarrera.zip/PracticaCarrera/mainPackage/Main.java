package mainPackage;

import carrera.Carrera;

public class Main {
	public static void main(String[] args) {
		Carrera carrera = new Carrera(4);
	}
}
